﻿using assignmentTwo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignmentTwo
{
    class ResourceBuilding : Building
    {
        public int resourceType;
        public int remainingResource;

        public int resourcePerGame;

        public int Max_Resources = 100;
        string saved_game = "";
        

        public override void isDead(Unit unit)
        {
            unit = null;
        }

        public override string toString()
        {
            string output = "x : " + X + Environment.NewLine
                 + "y : " + Y + Environment.NewLine
                 + "Health : " + Health + Environment.NewLine
                // + "Speed : " + Speed + Environment.NewLine
                // + "Attack : " + (Attack ? "Yes" : "No") + Environment.NewLine
                // + "Attack Range : " + AttackRange + Environment.NewLine
                 + "Faction/Team : " + Faction + Environment.NewLine
                 + "Symbol : " + Symbol + Environment.NewLine
                 + "Unit Name :" + unitName + Environment.NewLine;
            return output;
        }

        public void generateResources()
        {
            Random rnd = new Random();
            this.remainingResource = rnd.Next(0, Max_Resources);
        }

        public void removeResources(int ennemyStrenght)
        {
            if(ennemyStrenght > 85)
            {
                this.remainingResource -= 25;
            }
            else if(ennemyStrenght <= 85 && ennemyStrenght > 60)
            {
                this.remainingResource -= 15;
            }
            else if(ennemyStrenght <= 60 && ennemyStrenght > 40)
            {
                this.remainingResource -= 10;
            }
            else
            {
                this.remainingResource -= 5;
            }

        }

        public override void Save()
        {
            saved_game =  toString();
        }

        public override void read(string savedGame)
        {
            //split the sring to get the data from the saved gave and pass them to the egen
           var data_info = saved_game.Split(':');
        }
    }
}
