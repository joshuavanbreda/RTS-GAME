﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignmentTwo
{
    abstract class Building
    {
        protected int x;
        protected int y;
        protected int health;
        protected string faction;
        protected string symbol;
        protected string unitname;

 
        // Accessors 

        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }

        }

        public string Faction
        {
            get { return faction; }
            set { faction = value; }
        }

        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }

        public string unitName
        {
            get { return unitname; }
            set { unitname = value; }
        }

        //Constructors

        public Building()
        {

        }

        public Building(int posX, int posY, int health, string faction, string Symbol, string unitN)
        {
            this.X = posX;
            this.Y = posY;
            this.Health = health;
            this.Faction = faction;
            this.Symbol = Symbol;
            this.unitName = unitN;
        }

        //Set unit to null to declate it dead
        public abstract void isDead(Unit unit);

        //Print units information
        public abstract string toString();

        public abstract void Save();
        public abstract void read(string savedGame);



    }
}
