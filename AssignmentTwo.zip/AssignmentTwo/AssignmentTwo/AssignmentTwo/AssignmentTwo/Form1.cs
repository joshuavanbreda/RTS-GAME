﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignmentTwo
{
    public partial class Form1 : Form
    {
        GameEngine engine = new GameEngine();
        FactoryBuilding FB = new FactoryBuilding();
        string saved_game = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            btnPause.Enabled = true;
            timer1.Enabled = true;
            timer1.Start();
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            btnPause.Enabled = false;
            btnStart.Enabled = true;
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = System.DateTime.Now.ToLongTimeString();
            engine.start();

            lblShow.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblShow.Text += engine.map.Grid[i, j] + " ";
                }
                lblShow.Text += "\n";
            }
        }

        private void lblShow_Click_1(object sender, EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;

            int formX = this.Location.X;
            int formY = this.Location.Y;

            int Y = (mouseX - formX - 39 - 6) / 15;
            int X = (mouseY - formY - 70 - 1) / 15;

            txtDisplay.Text = "";
            foreach (Unit u in engine.map.UnitsOnMap)
            {
                if (u.X == X && u.Y == Y)
                    txtDisplay.Text += u.toString();
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.DialogResult result = MessageBox.Show("Are you sure ?", "Exit game", MessageBoxButtons.YesNo);
            {
                if (result == DialogResult.Yes)
                    Application.Exit();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblTime_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FB.Save();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FB.read(saved_game);
        }
    }
}   

